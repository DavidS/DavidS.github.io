#ifndef __Controller_H__
#define __Controller_H__

#include <SDL/SDL.h>
#include <map>

#include "World.h"
#include "Keyboard.h"
#include "Object.h"
#include "SmartPtr.h"


/**
 * Controls the player/game interaction.
 */

typedef void (*KeyActionFunctionPtr)(const SDLKey&);

class KeyAction
{
public:
	virtual ~KeyAction() {};
	virtual void execute(const SDLKey& key) const = 0;
};

class KeyActionFunction : public KeyAction
{
public:
	virtual ~KeyActionFunction() {};
	KeyActionFunction(KeyActionFunctionPtr func): theFunc(func) { };
	virtual void execute(const SDLKey& key) const { (*theFunc)(key); };
private:
	KeyActionFunctionPtr theFunc;
};

class KeyActionObject : public KeyAction
{
public:
	virtual ~KeyActionObject() {};
	typedef void (Object::* KeyActionObjectPtr)(const SDLKey&);
	KeyActionObject(SmartPtr<Object> object, KeyActionObjectPtr func): theObject(object), theFunc(func) { };
	virtual void execute(const SDLKey& key) const { ((*theObject).*theFunc)(key); };
private:
	SmartPtr<Object> theObject;
	KeyActionObjectPtr theFunc;
};

class Controller
{

public:

	Controller(); 
	virtual ~Controller();

	// Call this after initialising the display.
	// never returns
	void interact();

private:

	Keyboard theKeys;
	Uint32 theLastFrameDuration;

	std::map < const SDLKey, const KeyAction*> theKeyActions;

	void processEvents();
	void processKeyEvents();
};


#endif /* __Controller_H__ */
