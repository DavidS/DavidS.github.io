#include <iostream>
#include "BoundingBox.h"
#include "Object.h"

using namespace std;
	
BoundingBox::BoundingBox(Object* of, GLfloat dx, GLfloat dy, GLfloat dz, GLfloat width, GLfloat height, GLfloat depth)
: theObjectPtr(of), theOffset(dx,dy,dz), theSize(width, height, depth)
{
}

BoundingBox::BoundingBox(Object* of, GL::glVertex3D<GLfloat> off, GL::glVertex3D<GLfloat> size)
: theObjectPtr(of), theOffset(off), theSize(size)
{
}

BoundingBox::BoundingBox(const BoundingBox& other)
: theObjectPtr(other.theObjectPtr), theOffset(other.theOffset), theSize(other.theSize)
{
}

bool BoundingBox::intersecting(const BoundingBox& other)
{
	GL::glVertex3D<GLfloat> position = theObjectPtr->position() + theOffset;
	GL::glVertex3D<GLfloat> otherPosition = other.theObjectPtr->position() + other.theOffset;

	// check for overlap in x-direction
	if ((position.x() + theSize.x() < otherPosition.x())
		|| (otherPosition.x() + other.theSize.x() < position.x()))
	{
		return false;
	}

	// check for overlap in y-direction
	if ((position.y() + theSize.y() < otherPosition.y())
		|| (otherPosition.y() + other.theSize.y() < position.y()))
	{
		return false;
	}

	// check for overlap in z-direction
	if ((position.z() + theSize.z() < otherPosition.z())
		|| (otherPosition.z() + other.theSize.z() < position.z()))
	{
		return false;
	}

	// if BBs overlap in all three dimensions, the BBs intersect:
	return true;

}

