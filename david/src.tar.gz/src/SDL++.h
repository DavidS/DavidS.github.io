#ifndef __SDLPLUSPLUS_H__
#define __SDLPLUSPLUS_H__

#include <SDL/SDL.h>
#include <cassert>

namespace SDL
{

	class Surface
	{
	public:
		Surface(const char* bmpfilename) { theSurface = SDL_LoadBMP(bmpfilename); };
		~Surface() { if (theSurface) SDL_FreeSurface(theSurface); }

		void lock() { assert(theSurface); SDL_LockSurface(theSurface); };
		void unlock() { assert(theSurface); SDL_UnlockSurface(theSurface); };
		
		SDL_Surface* theSurface;
	private:

		// Disallow
		Surface(const Surface& other) {};

	};
	
}

#endif /* __SDLPLUSPLUS_H__ */
