#ifndef __BMPTerrain_H__
#define __BMPTerrain_H__

#include "Terrain.h"

/**
 * Load Terrain from a BMP-Heightmap
 */

class BMPTerrain
: public Terrain
{

public:

	BMPTerrain(const char* filename);
	virtual ~BMPTerrain();

protected:
	virtual float heightMapAt(int x, int y) const;
private:

	unsigned int theHeight, theWidth;
	Uint8* theHeightMap;

};


#endif /* __BMPTerrain_H__ */
