#ifndef __World_H__
#define __World_H__

#include <SDL/SDL.h>
#include <vector>
#include "Camera.h"
#include "SmartPtr.h"

class Object;
class Player;
class Terrain;

/**
 * Controls the player/game interaction.
 */

class World
{
public:

	static World* theWorld();

	void update(Uint32 frameDuration);
	void draw();

	SmartPtr<Object> player();
	//Camera& camera() { return theCamera; };

	float heightAt(float x, float y) const;

private:

	World();
	virtual ~World();

	Terrain* theTerrain;
	SmartPtr<Object> thePlayer;
	Camera theCamera;

	std::vector< SmartPtr<Object> > theObjects;

};


#endif /* __World_H__ */
