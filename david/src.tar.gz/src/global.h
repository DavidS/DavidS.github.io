#ifndef __global_h__
#define __global_h__
// Global definitions

const float PI = 3.1415927f;

#endif /* ifndef __global_H__ */
