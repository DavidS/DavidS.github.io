#ifndef __Terrain_H__
#define __Terrain_H__

#include "OpenGL.h"
#include "Texture.h"

/**
 * This class handles the terrain. As a first step, we just display a flat
 * square.
 */

class Terrain
{

public:

	Terrain();
	virtual ~Terrain();

	virtual void initialise();
	void draw() const;
	float heightAt(float x, float y) const;


protected:
	virtual float heightMapAt(int x, int y) const;
	GL::glVertex3D<GLfloat> calcVertex(int x, int y) const;
	void drawVertex(int x, int y) const;
private:

	GLuint theTerrainList;
	GL::Texture theTexture;

};


#endif /* __Terrain_H__ */
