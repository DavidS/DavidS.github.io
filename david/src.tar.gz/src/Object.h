#ifndef __Object_H__
#define __Object_H__

#include <SDL/SDL.h>
#include "OpenGLMath.h"

#include "BoundingBox.h"

/**
 * An Object in the World
 */

class Object
{

public:

	Object();
	virtual ~Object() { };

	virtual void draw() const;
	virtual void update(Uint32 time);
	
	virtual void triggerForward(const SDLKey&) { goesForward = true; };
	virtual void triggerBack(const SDLKey&) { goesBackwards = true; };
	virtual void triggerLeft(const SDLKey&) { turnsLeft = true; };
	virtual void triggerRight(const SDLKey&) { turnsRight = true; };

	virtual void forward(Uint32 time);
	virtual void back(Uint32 time);
	virtual void left(Uint32 time);
	virtual void right(Uint32 time);

	virtual bool intersecting(const Object& other) { return theBoundingBox.intersecting(other.theBoundingBox); }

	virtual GL::glVertex3D<GLfloat> position() const { return thePosition; };
	virtual GL::glVertex3D<GLfloat> forwardVector() const { return theForwardVector; };

protected:
	virtual void normalizeForwardVector();

private:

	bool goesForward, goesBackwards, turnsRight, turnsLeft;

	GL::glVertex3D<GLfloat> thePosition;	
	GL::glVertex3D<GLfloat> theForwardVector;

	BoundingBox theBoundingBox;

};


#endif /* __Object_H__ */
