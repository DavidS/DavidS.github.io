#ifndef __Keyboard_H__
#define __Keyboard_H__

#include <SDL/SDL.h>
#include <set>

/**
 * Keeps track of the keyboard state
 */

class Keyboard
{

public:

	Keyboard() { }; 
	virtual ~Keyboard() { };

	void pressKey(const SDLKey& pressedKey);
	void releaseKey(const SDLKey& releasedKey);

	void clear();

	bool isPressed(SDLKey whichKey) const;

private:

	std::set<SDLKey> theActiveKeys;

};


#endif /* __Keyboard_H__ */
