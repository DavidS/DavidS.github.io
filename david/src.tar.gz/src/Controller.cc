#include "Controller.h"
#include "World.h"
#include "Object.h"
#include "Player.h"

#include <iostream>
#include <cassert>
#include <SDL/SDL.h>

using namespace std;

void Controller::processKeyEvents()
{
	for (map<const SDLKey, const KeyAction*>::const_iterator currentKey = theKeyActions.begin();
			currentKey != theKeyActions.end();
			currentKey++)
	{
		if (theKeys.isPressed(currentKey->first))
		{
			currentKey->second->execute(currentKey->first);
		}
	}

}

void Controller::processEvents()
{
	SDL_Event event;
	while (SDL_PollEvent(&event))
	{
		switch (event.type)
		{
		case SDL_KEYUP:
			theKeys.releaseKey(event.key.keysym.sym);
			break;

		case SDL_KEYDOWN:
			theKeys.pressKey(event.key.keysym.sym);
			break;

		case SDL_MOUSEBUTTONUP:
		case SDL_MOUSEBUTTONDOWN:
		case SDL_MOUSEMOTION:
			// processMouseEvent(event);
			break;
		case SDL_QUIT:
			exit(0);
			break;
		default: 
			cout << "Unknown Eventtype" << endl;
			// GameDriver::reportError("Unknown Eventtype");
		}
	}
}

void Controller::interact()
{
	Uint32 lastTicks = SDL_GetTicks();
	World::theWorld()->draw();

	int frames = 1;
	Uint32 lastFpsPrint = lastTicks;
	while ( 1 )
	{
		Uint32 currentTicks = SDL_GetTicks();
		theLastFrameDuration = currentTicks - lastTicks;

		if (currentTicks - lastFpsPrint >= 1000)
		{
			cout << "fps: " << ((float)frames * 1000.0) / ((float)(currentTicks - lastFpsPrint)) << endl;
			frames = 0;
			lastFpsPrint = currentTicks;
		}

		// events
		processEvents();
		processKeyEvents();
		// update
		World::theWorld()->update(theLastFrameDuration);
		// draw
		World::theWorld()->draw();

		frames += 1;
		lastTicks = currentTicks;
	}
}

void doExit(const SDLKey& pressed)
{
	// std::cout << "bailing out\n";
	// ((KeyActionFunctionPtr)0)(pressed, time);
	exit(0);
}

Controller::Controller()
{
	theKeyActions[SDLK_e] = new KeyActionObject(World::theWorld()->player(), &Player::triggerForward);
	theKeyActions[SDLK_UP] = new KeyActionObject(World::theWorld()->player(), &Player::triggerForward);

	theKeyActions[SDLK_s] = new KeyActionObject(World::theWorld()->player(), &Player::triggerLeft);
	theKeyActions[SDLK_LEFT] = new KeyActionObject(World::theWorld()->player(), &Player::triggerLeft);

	theKeyActions[SDLK_d] = new KeyActionObject(World::theWorld()->player(), &Player::triggerBack);
	theKeyActions[SDLK_DOWN] = new KeyActionObject(World::theWorld()->player(), &Player::triggerBack);

	theKeyActions[SDLK_f] = new KeyActionObject(World::theWorld()->player(), &Player::triggerRight);
	theKeyActions[SDLK_RIGHT] = new KeyActionObject(World::theWorld()->player(), &Player::triggerRight);

	theKeyActions[SDLK_q] = new KeyActionFunction(&doExit);
	theKeyActions[SDLK_ESCAPE] = new KeyActionFunction(&doExit);

}

Controller::~Controller()
{

}

