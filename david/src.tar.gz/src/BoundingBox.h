#ifndef __BoundingBox_H__
#define __BoundingBox_H__

/**
 * Defines the axis-paralell-bounding-box of an Object
 */
#include "OpenGLMath.h"

class Object;

class BoundingBox
{

public:

	BoundingBox(
		Object* target,
		GL::glVertex3D<GLfloat> offset,
		GL::glVertex3D<GLfloat> size
		);
	BoundingBox(
		Object* target,
		GLfloat dx, GLfloat dy, GLfloat dz,
		GLfloat width, GLfloat height, GLfloat depth
		);
	BoundingBox(const BoundingBox& other);
	virtual ~BoundingBox() { };

	bool intersecting(const BoundingBox& other);

private:
	const Object* theObjectPtr;
	GL::glVertex3D<GLfloat> theOffset;
	GL::glVertex3D<GLfloat> theSize;
};


#endif /* __BoundingBox_H__ */
