#ifndef __Camera_H__
#define __Camera_H__

#include "OpenGL.h"
#include "SmartPtr.h"
#include "Object.h"
using namespace GL;

/**
 * Encapsulates View and perspective
 */

class Camera
{

public:

	Camera(SmartPtr<Object> followThis);
	virtual ~Camera();

	void forward();
	void back();
	void left();
	void right();
	void updateGL();

private:

	glVertex3D<GLfloat> theForwardVector;
	glVertex3D<GLfloat> theUpVector;
	SmartPtr<Object>  theObject;

};


#endif /* __Camera_H__ */
