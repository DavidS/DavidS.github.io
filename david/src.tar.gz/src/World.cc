#include "World.h"
#include "Object.h"
#include "Player.h"
#include "OpenGL.h"
#include "Light.h"
#include "BMPTerrain.h"

#include <iostream>

using namespace std;

World* World::theWorld()
{
	static World singleton;
	return &singleton;
}

World::World()
	: thePlayer(new Player()),
	  theCamera(thePlayer)
{
	theObjects.push_back(thePlayer);
	theObjects.push_back(SmartPtr<Object>(new Object()));
	theTerrain = new Terrain();
	// theTerrain = new BMPTerrain("terrain.bmp");
	theTerrain->initialise();
}

World::~World()
{
	if (theTerrain) delete theTerrain;
}

float World::heightAt(float x, float y) const 
{
	return theTerrain->heightAt(x,y);
};

void World::draw()
{
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );

	theCamera.updateGL();
	Light::getLight(GL_LIGHT0)->updateGL();

	// draw something
	theTerrain->draw();
	for (vector< SmartPtr<Object> >::const_iterator currentObject = theObjects.begin();
			currentObject != theObjects.end();
			++currentObject)
	{
		(*currentObject)->draw();
	}
	
	glFlush();
	SDL_GL_SwapBuffers();
}

SmartPtr<Object> World::player() 
{
	return thePlayer;
}

void World::update(Uint32 frameDuration)
{
	for (vector< SmartPtr<Object> >::iterator currentObject = theObjects.begin();
			currentObject != theObjects.end();
			++currentObject)
	{
		(*currentObject)->update(frameDuration);
	}

	for (vector< SmartPtr<Object> >::iterator firstObject = theObjects.begin();
			firstObject != theObjects.end();
			++firstObject)
	{
		for (vector< SmartPtr<Object> >::iterator secondObject = (firstObject + 1);
				secondObject != theObjects.end();
				++secondObject)
		{
			if ( (*firstObject)->intersecting(**secondObject) )
			{
				cout << ".";
			}
		}
	}
}


