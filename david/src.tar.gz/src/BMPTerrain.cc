
#include <SDL/SDL.h>
#include "SDL++.h"
#include "BMPTerrain.h"
#include <cstring>
#include <iostream>

using namespace std;
using namespace SDL;

BMPTerrain::BMPTerrain(const char* filename)
{
	Surface surface(filename);

	// only works with palletized 8bit pics.
	assert(surface.theSurface->format->BitsPerPixel == 8);
	
	theHeight = surface.theSurface->h;
	theWidth = surface.theSurface->w;

	theHeightMap = new Uint8[theHeight*theWidth];
	surface.lock();
	memcpy(theHeightMap, surface.theSurface->pixels, theHeight*theWidth);
	surface.unlock();

	cout << "loaded from " << filename << endl;

}

BMPTerrain::~BMPTerrain()
{
	delete[] theHeightMap;
}

float BMPTerrain::heightMapAt(int x, int y) const
{
	return (theHeightMap[x + y*theHeight] / 25.6); // scale to [0, 10]
	// return x*y / 1000.0;
}

