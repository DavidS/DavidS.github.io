#include "Keyboard.h"

void Keyboard::pressKey(const SDLKey& pressedKey)
{
	theActiveKeys.insert(pressedKey);
}

void Keyboard::releaseKey(const SDLKey& releasedKey)
{
	theActiveKeys.erase(releasedKey);
}

void Keyboard::clear()
{
	theActiveKeys.clear();
}

bool Keyboard::isPressed(SDLKey whichKey) const
{
	return (theActiveKeys.find(whichKey) != theActiveKeys.end());
}

