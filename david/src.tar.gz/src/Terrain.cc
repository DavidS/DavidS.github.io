
#include <SDL/SDL.h>
#include "OpenGL.h"
#include <cmath>
#include <iostream>

#include "Terrain.h"

using namespace GL;
using namespace std;

float Terrain::heightMapAt(int x, int y) const
{
	return sin((float)x*y / 10);
	// return x*y / 1000.0;
}

float Terrain::heightAt(float x, float y) const
{
	float floorX = floorf(x);
	float floorY = floorf(y);

	float offX = x - floorX;
	float offY = y - floorY;

	float ceilX = ceilf(x);
	float ceilY = ceilf(y);

	float avgLowerY = (1-offX)*heightMapAt((int)floorX, (int)floorY) + offX*heightMapAt((int)ceilX , (int)floorY);
	float avgUpperY = (1-offX)*heightMapAt((int)floorX, (int) ceilY) + offX*heightMapAt((int)ceilX , (int) ceilY);

	return ((1-offY) * avgLowerY + offY * avgUpperY);
}

glVertex3D<GLfloat> Terrain::calcVertex(int x, int y) const
{
	return glVertex3D<GLfloat>(x, heightMapAt(x,y), y);
}

void Terrain::drawVertex(int x, int y) const
{
	glVertex3D<GLfloat> vertex = calcVertex(x,y);
	// the six neighbouring vertices
	glVertex3D<GLfloat> neighbours[] = {
		calcVertex(x+1,y  ) - vertex,
		calcVertex(x  ,y+1) - vertex,
		calcVertex(x-1,y+1) - vertex,
		calcVertex(x-1,y  ) - vertex,
		calcVertex(x  ,y-1) - vertex,
		calcVertex(x+1,y-1) - vertex
	};
	
	// average over the normals of all four adjacent faces
	glVertex3D<GLfloat> normal(0.0f, 0.0f, 0.0f);
	for (int i = 0; i < 6; ++i)
	{
		normal += neighbours[(i+1) % 6].cross(neighbours[i]);
		// normal += neighbours[i].cross(neighbours[(i+1) % 6]);
	}
	normal /= 6;
	normal.normalize();

	// cout << "N" << normal << endl;

	// normal = glVertex3D<GLfloat>(0.0, 1.0, 0.0);

	glNormal(normal);
	glVertex(vertex);
	// glVertex(vertex+normal);
}

Terrain::Terrain()
: theTerrainList(glGenLists(1)),
	theTexture("grassy.bmp")
{
}


void Terrain::initialise()
{
	glNewList(theTerrainList, GL_COMPILE);
	theTexture.enable();
	for (int x = 0; x < 128 ; x++ )
	{
		glBegin( GL_TRIANGLE_STRIP );
		// glBegin( GL_LINES );
		for (int z = 0; z < 128; z++ )
		{
			glColor3f(1,1,1);

			glTexCoord(0,0);
			drawVertex(x  , z  );
			glTexCoord(1,0);
			drawVertex(x+1, z  );
			glTexCoord(0,1);
			drawVertex(x  , z+1);
			glTexCoord(1,1);
			drawVertex(x+1, z+1);
		}
		glEnd();
	}
	theTexture.disable();
	glEndList();
}

Terrain::~Terrain() 
{
	glDeleteLists(theTerrainList,1);
}

void Terrain::draw() const
{
	glCallList(theTerrainList);
}

