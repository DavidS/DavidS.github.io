
#include "Controller.h"

#include <iostream>
#include <SDL/SDL.h>
#include "OpenGL.h"
#include "Light.h"

using namespace std;
using namespace GL;

void reportError(char* message)
{
	cout << "Current Action: " << message << endl;
	cout << "Last SDL Error" << endl;
	cout << SDL_GetError() << endl;
	cout << "Last GL Error" << endl;
	cout << gluErrorString(glGetError()) << endl;
}

void initGL()
{

	glClearColor(0.0, 0.0, 0.0, 0.0);
	glClearDepth(1.0);

	glShadeModel(GL_SMOOTH);
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_NORMALIZE);
	glEnable(GL_CULL_FACE);
	glFrontFace(GL_CW);
	glPixelStorei(GL_UNPACK_ALIGNMENT, 1);

	// hack default material
	glVertex4D<GLfloat> diffuse(1.0, 1.0, 1.0, 1.0);
	glVertex4D<GLfloat> specular(0.01, 0.01, 0.01, 1.0);
	GLfloat shininess = 25.0;
	glMaterialfv(GL_FRONT, GL_DIFFUSE, diffuse);
	glMaterialfv(GL_FRONT, GL_SPECULAR, specular);
	glMaterialf(GL_FRONT, GL_SHININESS, shininess);

	// create infinite directional light
	Light* sun = Light::getLight(GL_LIGHT0);
	glVertex4D<GLfloat> sunPosition(1.0, 1.0, 1.0, 0.0);
	sun->setPosition(sunPosition);

	// GLfloat sunPosition[] = { 1.0, 500.0, 1.0, 0.0 };
	// glLightfv(GL_LIGHT0, GL_POSITION, sunPosition);
	// glVertex4D<GLfloat> sunDiffColor(0.5, 1.0, 1.0, 1.0);
	// glLightfv(GL_LIGHT0, GL_DIFFUSE, sunDiffColor);
	// glLightfv(GL_LIGHT0, GL_SPECULAR, sunDiffColor);
	// glVertex4D<GLfloat> sunAmbColor(1.0, 1.0, 1.0, 1.0);
	// glLightfv(GL_LIGHT0, GL_DIFFUSE, sunAmbColor);
	glEnable(GL_LIGHTING);
	// glEnable(GL_LIGHT0);
	sun->enable();

	glColorMaterial(GL_FRONT, GL_DIFFUSE);
	glEnable(GL_COLOR_MATERIAL);

	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
	glViewport( 0, 0, 640, 480 );
	glMatrixMode( GL_PROJECTION );
	gluPerspective( 60.0, 640.0/480.0, 1.0, 1024.0 );
	glMatrixMode( GL_MODELVIEW );
	glLoadIdentity();


	reportError("after initGL()");

}

const SDL_VideoInfo* videoInfo = 0;
int main(int argc, char** argv)
{

	cout << "Welcome to magehack." << endl << "Loading Game ..." << endl;

	if (( SDL_Init( SDL_INIT_VIDEO | SDL_INIT_AUDIO ) == -1 )) 
		reportError("SDL_Init");

	atexit(SDL_Quit);

	videoInfo = SDL_GetVideoInfo( );
	if (videoInfo == 0)
		reportError("SDL_GetVideoInfo");

	SDL_GL_SetAttribute( SDL_GL_RED_SIZE, 5 );
	SDL_GL_SetAttribute( SDL_GL_GREEN_SIZE, 5 );
	SDL_GL_SetAttribute( SDL_GL_BLUE_SIZE, 5 );
	SDL_GL_SetAttribute( SDL_GL_DEPTH_SIZE, 16 );
	SDL_GL_SetAttribute( SDL_GL_DOUBLEBUFFER, 1);

	if ( SDL_SetVideoMode( 640, 480,
		videoInfo->vfmt->BitsPerPixel, SDL_OPENGL /* | SDL_FULLSCREEN */)
		== 0 )
	{
		reportError("GL_Init");
	}

	initGL();

	Controller game;
	game.interact();

	cout << "Goodbye!" << endl;
}
