
#include "SDL++.h"
#include "OpenGL.h"
#include "Texture.h"
#include <cassert>

namespace GL
{

Texture::Texture(char * filename)
{
	SDL::Surface surface(filename);
	assert(surface.theSurface->format->BitsPerPixel == 24);
	// FIXME: quite probable, the texture should be rotated by 90� 
	// to compensate C vs. GL byteordering
	
	glGenTextures(1, &theTexNumber);
	glBindTexture(GL_TEXTURE_2D, theTexNumber);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, surface.theSurface->w, surface.theSurface->h, 0, GL_RGB, GL_UNSIGNED_BYTE, surface.theSurface->pixels);

}

Texture::~Texture()
{
		glDeleteTextures(1, &theTexNumber);
}

void Texture::disable() const
{
	glDisable(GL_TEXTURE_2D);
}

void Texture::enable() const
{
	glEnable(GL_TEXTURE_2D);
	// glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
	glBindTexture(GL_TEXTURE_2D, theTexNumber);
}


}
