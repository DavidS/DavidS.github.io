#ifndef __OpenGL_H__
#define __OpenGL_H__

#include <GL/gl.h>
#include <GL/glu.h>

#include "OpenGLMath.h"

namespace GL
{
	class OpenGLState
	{

	};
	
	inline void glVertex( GLshort x, GLshort y ) { glVertex2s( x, y ); };
	inline void glVertex( GLint x, GLint y ) { glVertex2i( x, y ); };
	inline void glVertex( GLfloat x, GLfloat y ) { glVertex2f( x, y ); };
	inline void glVertex( GLdouble x, GLdouble y ) { glVertex2d( x, y ); };

	inline void glVertex( GLshort x, GLshort y, GLshort z ) { glVertex3s( x, y, z ); };
	inline void glVertex( GLint x, GLint y, GLint z ) { glVertex3i( x, y, z ); };
	inline void glVertex( GLfloat x, GLfloat y, GLfloat z ) { glVertex3f( x, y, z ); };
	inline void glVertex( GLdouble x, GLdouble y, GLdouble z ) { glVertex3d( x, y, z ); };

	inline void glVertex( GLshort x, GLshort y, GLshort z, GLshort w ) { glVertex4s( x, y, z, w ); };
	inline void glVertex( GLint x, GLint y, GLint z, GLint w ) { glVertex4i( x, y, z, w ); };
	inline void glVertex( GLfloat x, GLfloat y, GLfloat z, GLfloat w ) { glVertex4f( x, y, z, w ); };
	inline void glVertex( GLdouble x, GLdouble y, GLdouble z, GLdouble w ) { glVertex4d( x, y, z, w ); };
 
	inline void glVertex( const glVertex2D<GLshort>& v ) { glVertex2sv( v ); };
	inline void glVertex( const glVertex2D<GLint>& v ) { glVertex2iv( v ); };
	inline void glVertex( const glVertex2D<GLfloat>& v ) { glVertex2fv( v ); };
	inline void glVertex( const glVertex2D<GLdouble>& v ) { glVertex2dv( v ); };

	inline void glVertex( const glVertex3D<GLshort>& v ) { glVertex3sv( v ); };
	inline void glVertex( const glVertex3D<GLint>& v ) { glVertex3iv( v ); };
	inline void glVertex( const glVertex3D<GLfloat>& v ) { glVertex3fv( v ); };
	inline void glVertex( const glVertex3D<GLdouble>& v ) { glVertex3dv( v ); };

	inline void glVertex( const glVertex4D<GLshort>& v ) { glVertex4sv( v ); };
	inline void glVertex( const glVertex4D<GLint>& v ) { glVertex4iv( v ); };
	inline void glVertex( const glVertex4D<GLfloat>& v ) { glVertex4fv( v ); };
	inline void glVertex( const glVertex4D<GLdouble>& v ) { glVertex4dv( v ); };

	inline void glNormal( GLbyte nx, GLbyte ny, GLbyte nz ) { glNormal3b( nx, ny, nz ); }; 
	inline void glNormal( GLdouble nx, GLdouble ny, GLdouble nz ) { glNormal3d( nx, ny, nz ); }; 
	inline void glNormal( GLfloat nx, GLfloat ny, GLfloat nz ) { glNormal3f( nx, ny, nz ); }; 
	inline void glNormal( GLint nx, GLint ny, GLint nz ) { glNormal3i( nx, ny, nz ); }; 
	inline void glNormal( GLshort nx, GLshort ny, GLshort nz ) { glNormal3s( nx, ny, nz ); }; 

	inline void glNormal( const GLbyte *v ) { glNormal3bv( v ); }; 
	inline void glNormal( const GLdouble *v ) { glNormal3dv( v ); }; 
	inline void glNormal( const GLfloat *v ) { glNormal3fv( v ); }; 
	inline void glNormal( const GLint *v ) { glNormal3iv( v ); }; 
	inline void glNormal( const GLshort *v ) { glNormal3sv( v ); }; 

	inline void glColor( GLbyte red, GLbyte green, GLbyte blue ) { glColor3b( red, green, blue ); }; 
	inline void glColor( GLdouble red, GLdouble green, GLdouble blue ) { glColor3d( red, green, blue ); }; 
	inline void glColor( GLfloat red, GLfloat green, GLfloat blue ) { glColor3f( red, green, blue ); }; 
	inline void glColor( GLint red, GLint green, GLint blue ) { glColor3i( red, green, blue ); }; 
	inline void glColor( GLshort red, GLshort green, GLshort blue ) { glColor3s( red, green, blue ); }; 

	inline void glColor( GLubyte red, GLubyte green, GLubyte blue ) { glColor3ub( red, green, blue ); }; 
	inline void glColor( GLuint red, GLuint green, GLuint blue ) { glColor3ui( red, green, blue ); }; 
	inline void glColor( GLushort red, GLushort green, GLushort blue ) { glColor3us( red, green, blue ); }; 

	inline void glColor( GLbyte red, GLbyte green, GLbyte blue, GLbyte alpha ) { glColor4b( red, green, blue, alpha ); }; 
	inline void glColor( GLdouble red, GLdouble green, GLdouble blue, GLdouble alpha ) { glColor4d( red, green, blue, alpha ); }; 
	inline void glColor( GLfloat red, GLfloat green, GLfloat blue, GLfloat alpha ) { glColor4f( red, green, blue, alpha ); }; 
	inline void glColor( GLint red, GLint green, GLint blue, GLint alpha ) { glColor4i( red, green, blue, alpha ); }; 

	inline void glColor( GLshort red, GLshort green, GLshort blue, GLshort alpha ) { glColor4s( red, green, blue, alpha ); }; 
	inline void glColor( GLubyte red, GLubyte green, GLubyte blue, GLubyte alpha ) { glColor4ub( red, green, blue, alpha ); }; 
	inline void glColor( GLuint red, GLuint green, GLuint blue, GLuint alpha ) { glColor4ui( red, green, blue, alpha ); }; 
	inline void glColor( GLushort red, GLushort green, GLushort blue, GLushort alpha ) { glColor4us( red, green, blue, alpha ); }; 

	inline void glColor3( const GLbyte *v ) { glColor3bv( v ); }; 
	inline void glColor3( const GLdouble *v ) { glColor3dv( v ); }; 
	inline void glColor3( const GLfloat *v ) { glColor3fv( v ); }; 
	inline void glColor3( const GLint *v ) { glColor3iv( v ); }; 
	inline void glColor3( const GLshort *v ) { glColor3sv( v ); }; 

	inline void glColor3( const GLubyte *v ) { glColor3ubv( v ); }; 
	inline void glColor3( const GLuint *v ) { glColor3uiv( v ); }; 
	inline void glColor3( const GLushort *v ) { glColor3usv( v ); }; 

	inline void glColor4( const GLbyte *v ) { glColor4bv( v ); }; 
	inline void glColor4( const GLdouble *v ) { glColor4dv( v ); }; 
	inline void glColor4( const GLfloat *v ) { glColor4fv( v ); }; 
	inline void glColor4( const GLint *v ) { glColor4iv( v ); }; 
	inline void glColor4( const GLshort *v ) { glColor4sv( v ); }; 

	inline void glColor4( const GLubyte *v ) { glColor4ubv( v ); }; 
	inline void glColor4( const GLuint *v ) { glColor4uiv( v ); }; 
	inline void glColor4( const GLushort *v ) { glColor4usv( v ); }; 


	// glMaterial allows only GL_SHININESS with single parameter
	inline void glShininess( GLenum face, GLfloat param ) { glMaterialf( face, GL_SHININESS, param ); }; 
	inline void glShininess( GLenum face, GLint param ) { glMateriali( face, GL_SHININESS, param ); }; 

	// FIXME: substitute GLenums with C++ enums
	// FIXME: create different functions for various pname values
	inline void glMaterial( GLenum face, GLenum pname, const GLfloat *params ) { glMaterialfv( face, pname, params ); }; 
	inline void glMaterial( GLenum face, GLenum pname, const GLint *params ) { glMaterialiv( face, pname, params ); }; 

	inline void glRotate(float angle, float x, float y, float z) { glRotatef(angle,x,y,z); }
	inline void glRotate(double angle, double x, double y, double z) { glRotated(angle,x,y,z); }

	inline void glTranslate(float x, float y, float z) { glTranslatef(x,y,z); }
	inline void glTranslate(double x, double y, double z) { glTranslated(x,y,z); }
	template<class T> inline void glTranslate(const glVertex3D<T>& to) { glTranslate(to.x(),to.y(),to.z()); }

	template<class T> inline void gluLookAt(const glVertex3D<T>& eye, const glVertex3D<T>& center, const glVertex3D<T>& up) 
	{
		::gluLookAt(
				(GLdouble)eye.x(), (GLdouble)eye.y(), (GLdouble)eye.z(),
				(GLdouble)center.x(), (GLdouble)center.y(), (GLdouble)center.z(), 
				(GLdouble)up.x(), (GLdouble)up.y(), (GLdouble)up.z()
				);
	};

}

#endif /* __OpenGL_H__ */
