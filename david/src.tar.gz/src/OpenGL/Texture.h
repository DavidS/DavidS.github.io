#ifndef __Texture_H__
#define __Texture_H__

/**
 * This class handles the loading and controlling of a texture.
 */

#include "OpenGL.h"

namespace GL
{

class Texture
{

public:

	Texture(char * filename);
	virtual ~Texture();

	void enable() const;
	void disable() const;

private:

	Texture(const Texture& other) { assert(false); } // DISALLOW
	GLuint theTexNumber;

};

inline void glTexCoord(GLshort s, GLshort t)	{ glTexCoord2s(s,t); };
inline void glTexCoord(GLint s, GLint t)	{ glTexCoord2i(s,t); };
inline void glTexCoord(GLfloat s, GLfloat t)	{ glTexCoord2f(s,t); };
inline void glTexCoord(GLdouble s, GLdouble t)	{ glTexCoord2d(s,t); };


}

#endif /* __Texture_H__ */
