#ifndef __OpenGLMath_H__
#define __OpenGLMath_H__

#include <iostream>
#include <cstring>
#include <GL/gl.h>

namespace GL
{

	template<class T> class glVertex2D 
	{
	public:
		glVertex2D( ): data(new T[2]) { data[0] = 0.0; data[1] = 0.0; };
		glVertex2D( T x, T y ): data(new T[2]) { data[0] = x; data[1] = y; };
		glVertex2D( T* fromData ): data(new T[2]) { memcpy(data, fromData, 2*sizeof(T)); };
		glVertex2D( const glVertex2D<T>& other ): data(new T[2]) { memcpy(data, other.data, 2*sizeof(T)); };
		~glVertex2D() { delete data; };
		T x() const { return data[0]; };
		T y() const { return data[1]; };
		operator const T* () const { return data; };
		// don't ==> operator T*() is defined glVertex2D<T>& operator =  (const T* rhs) { memcpy(data, rhs, 2*sizeof(T)); return *this; };
		glVertex2D<T>& operator =  (const glVertex2D<T>& rhs) { memcpy(data, rhs.data, 2*sizeof(T)); return *this; };
		glVertex2D<T>& operator += (const glVertex2D<T>& rhs) { data[0] += rhs.x(); data[1] += rhs.y(); return *this;}
		glVertex2D<T>& operator -= (const glVertex2D<T>& rhs) { data[0] -= rhs.x(); data[1] -= rhs.y(); return *this;}
	private:
		T* data;
	};

	template<class T> class glVertex3D 
	{
	public:
		glVertex3D( ): data(new T[3]) { data[0] = 0.0; data[1] = 0.0; data[2] = 0.0; };
		glVertex3D( T x, T y, T z ): data(new T[3]) { data[0] = x; data[1] = y; data[2] = z; };
		glVertex3D( T* fromData ): data(new T[3]) { memcpy(data, fromData, 3*sizeof(T)); };
		glVertex3D( const glVertex3D<T>& other ): data(new T[3]) { memcpy(data, other.data, 3*sizeof(T)); };
		~glVertex3D() { delete data; };
		T x() const { return data[0]; };
		T y() const { return data[1]; };
		T z() const { return data[2]; };
		
		T mag() const { return sqrt( x()*x() + y()*y() + z()*z() ); };
		void normalize() { T magnitude = mag(); data[0] /= magnitude; data[1] /= magnitude; data[2] /= magnitude; };
		
		operator const T* () const { return data; };
		// don't ==> operator T*() is defined glVertex3D<T>& operator =  (const T* rhs) { memcpy(data, rhs, 3*sizeof(T)); return *this; };
		glVertex3D<T>& operator =  (const glVertex3D<T>& rhs) { memcpy(data, rhs.data, 3*sizeof(T)); return *this; };
		glVertex3D<T>& operator += (const glVertex3D<T>& rhs) {
			data[0] += rhs.x(); data[1] += rhs.y(); data[2] += rhs.z(); return *this;
		};
		glVertex3D<T>& operator -= (const glVertex3D<T>& rhs) {
			data[0] -= rhs.x(); data[1] -= rhs.y(); data[2] -= rhs.z(); return *this;
		};
		glVertex3D<T>& operator *= (T rhs) {
			data[0] *= rhs; data[1] *= rhs; data[2] *= rhs; return *this; 
		};
		glVertex3D<T>& operator /= (T rhs) {
			data[0] /= rhs; data[1] /= rhs; data[2] /= rhs; return *this; 
		};
		glVertex3D<T> cross(const glVertex3D<T>& rhs)
		{
			return glVertex3D<T>(y()*rhs.z() - z()*rhs.y(), z()*rhs.x() - x()*rhs.z(), x()*rhs.y() - y()*rhs.x());
		};
	private:
		T* data;
	};

	template<class T> 
	std::ostream& operator<< (std::ostream& stream, const glVertex3D<T>& what)
	{
		return stream << "( " << what.x() << ", " << what.y() << ", " << what.z() << " )";
	}

	template<class T>
	glVertex3D<T> operator * (const glVertex3D<T>& lhs, T rhs) {
		glVertex3D<T> tmp(lhs);
		tmp *= rhs;
		return tmp;
	}

	template<class T>
	glVertex3D<T> operator * (T lhs, const glVertex3D<T>& rhs) {
		glVertex3D<T> tmp(rhs);
		tmp *= lhs;
		return tmp;
	}

	template<class T>
	glVertex3D<T> operator + (const glVertex3D<T>& lhs, const glVertex3D<T>& rhs) {
		glVertex3D<T> tmp(lhs);
		tmp += rhs;
		return tmp;
	}

	template<class T>
	glVertex3D<T> operator - (const glVertex3D<T>& lhs, const glVertex3D<T>& rhs) {
		glVertex3D<T> tmp(lhs);
		tmp -= rhs;
		return tmp;
	}

	template<class T>
	glVertex3D<T> operator / (const glVertex3D<T>& lhs, T rhs) {
		glVertex3D<T> tmp(lhs);
		tmp /= rhs;
		return tmp;
	}

	template<class T> class glVertex4D 
	{
	public:
		glVertex4D( ): data(new T[4]) { data[0] = 0.0; data[1] = 0.0; data[2] = 0.0; data[3] = 0.0; };
		glVertex4D( T x, T y, T z, T w ): data(new T[4]) { data[0] = x; data[1] = y; data[2] = z; data[3] = w; };
		glVertex4D( T* fromData ): data(new T[4]) { memcpy(data, fromData, 4*sizeof(T)); };
		glVertex4D( const glVertex4D<T>& other ): data(new T[4]) { memcpy(data, other.data, 4*sizeof(T)); };
		~glVertex4D() { delete data; };
		T x() const { return data[0]; };
		T y() const { return data[1]; };
		T z() const { return data[2]; };
		T w() const { return data[3]; };
		operator const T* () const { return data; };
		// don't ==> operator T*() is defined glVertex4D<T>& operator =  (const T* rhs) { memcpy(data, rhs, 4*sizeof(T)); return *this; };
		glVertex4D<T>& operator =  (const glVertex4D<T>& rhs) { memcpy(data, rhs.data, 4*sizeof(T)); return *this; };
		glVertex4D<T>& operator += (const glVertex4D<T>& rhs) {
			data[0] += rhs.x(); data[1] += rhs.y(); data[2] += rhs.z(); data[3] += rhs.w(); return *this;
		}
		glVertex4D<T>& operator -= (const glVertex4D<T>& rhs) {
			data[0] -= rhs.x(); data[1] -= rhs.y(); data[2] -= rhs.z(); data[3] += rhs.w(); return *this;
		}
	private:
		T* data;
	};

	template<class T> class glMatrix3x3
	{
	public:
		glMatrix3x3() : data(new T[9]) { };
		glMatrix3x3(T* content) : data(new T[9]) { memcpy(data, content, 9*sizeof(T)); };
		~glMatrix3x3() { if (data) delete data; data = 0; };

		glVertex3D<T> mult(const glVertex3D<T>& rhs)
		{
			T result[3] = {
				rhs.x() * data[0] + rhs.y() * data[3] + rhs.z() * data[6],
				rhs.x() * data[1] + rhs.y() * data[4] + rhs.z() * data[7],
				rhs.x() * data[2] + rhs.y() * data[5] + rhs.z() * data[8]
			};

			return glVertex3D<T>(result);
		};

	private: 
		T* data;
	};


}



#endif /* __OpenGLMath_H__ */
