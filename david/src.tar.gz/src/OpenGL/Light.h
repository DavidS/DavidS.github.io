#ifndef __Light_H__
#define __Light_H__

#include "OpenGL.h"
#include "OpenGLMath.h"

namespace GL
{

class Light
{
public:
	static Light* getLight(GLenum lightNum)
	{
		static bool initialised[]
		= {
			false, false, false, false,
			false, false, false, false 
		};
		static Light* theLights[8];

		int index = getLightIndex(lightNum);
		if ( !initialised[index] )
		{
			theLights[index] = new Light(lightNum);
			initialised[index] = true;
		}
		return theLights[index];
	};

	static int getLightIndex(GLenum lightNum)
	{
		switch(lightNum)
		{
			case GL_LIGHT0:	return 0;
			case GL_LIGHT1:	return 1;
			case GL_LIGHT2:	return 2;
			case GL_LIGHT3:	return 3;
			case GL_LIGHT4:	return 4;
			case GL_LIGHT5:	return 5;
			case GL_LIGHT6:	return 6;
			case GL_LIGHT7:	return 7;
			default:	assert(false); // not a GL_LIGHT[0-7]
		}
	};

	/*
	 * Begin member definitions
	 */

	void enable() { glEnable(theLightEnum); };
	void disable() { glDisable(theLightEnum); };

	void updateGL() { glLightfv(theLightEnum, GL_POSITION, thePosition); };

	void setPosition(glVertex4D<GLfloat> newPosition)
	{
		thePosition = newPosition;
		updateGL();
	}
	void setAmbientColor(glVertex4D<GLfloat> newAmbientColor) { glLightfv(theLightEnum, GL_AMBIENT, newAmbientColor); }
	void setDiffuseColor(glVertex4D<GLfloat> newDiffuseColor) { glLightfv(theLightEnum, GL_DIFFUSE, newDiffuseColor); }
	void setSpecularColor(glVertex4D<GLfloat> newSpecularColor) { glLightfv(theLightEnum, GL_SPECULAR, newSpecularColor); }

private:

	~Light() { };

	Light(GLenum lightNum)
		: theLightEnum(lightNum)
	{
	};

	GLenum theLightEnum;
	glVertex4D<GLfloat> thePosition;

};

}

#endif /* __Light_H__ */
