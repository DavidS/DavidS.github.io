#include "global.h"


#include "OpenGL.h"
#include "Object.h"
#include "World.h"

#include <iostream>
#include <cmath>

using namespace GL;
using namespace std;

const float deg45 = 0.78539816f;

Object::Object()
	: goesForward(false), goesBackwards(false), turnsRight(false), turnsLeft(false),
	  thePosition(10, -1, 10),
	  theForwardVector(0,0,-1),
	  theBoundingBox(this, glVertex3D<GLfloat>(0,0,0), glVertex3D<GLfloat>(1,1,1))
{
}

void Object::draw() const
{
	/*
	glBegin(GL_TRIANGLES);
	glColor(1.0f, 0.0f, 0.0f);
	glVertex(0.0f, 0.0f, 0.0f);
	glColor(0.0f, 1.0f, 0.0f);
	glVertex(1.0f, 1.0f, 0.0f);
	glColor(0.0f, 0.0f, 1.0f);
	glVertex(0.0f, 1.0f, 0.0f);
	glEnd();
	*/

	glPushMatrix();
	glTranslate(thePosition);
	float phi = acos(theForwardVector.z())*57.29578;
	if (theForwardVector.x()<0)
		phi = - phi;
	glRotate(phi, 0, 1, 0);
	glTranslate(-0.5,0.0,-0.5);
	
	//glRotate(45.0f, 0, 0, 1);
	//glRotate(45.0f, 1, 0, 0);

	glBegin(GL_QUADS);
		glColor(0.0f, 0.0f, 0.0f);
		glVertex(0, 0 ,0);
		glColor(0.0f, 1.0f, 0.0f);
		glVertex(0, 1, 0);
		glColor(1.0f, 1.0f, 0.0f);
		glVertex(1, 1, 0);
		glColor(1.0f, 0.0f, 0.0f);
		glVertex(1, 0, 0);

		glColor(0.0f, 0.0f, 0.0f);
		glVertex(0, 0, 0);
		glColor(1.0f, 0.0f, 0.0f);
		glVertex(1, 0, 0);
		glColor(1.0f, 0.0f, 1.0f);
		glVertex(1, 0, 1);
		glColor(0.0f, 0.0f, 1.0f);
		glVertex(0, 0, 1);

		glColor(0.0f, 0.0f, 0.0f);
		glVertex(0, 0, 0);
		glColor(0.0f, 0.0f, 1.0f);
		glVertex(0, 0, 1);
		glColor(0.0f, 1.0f, 1.0f);
		glVertex(0, 1, 1);
		glColor(0.0f, 1.0f, 0.0f);
		glVertex(0, 1, 0);

		glColor(1.0f, 1.0f, 1.0f);
		glVertex(1, 1, 1);
		glColor(1.0f, 1.0f, 0.0f);
		glVertex(1, 1, 0);
		glColor(0.0f, 1.0f, 0.0f);
		glVertex(0, 1, 0);
		glColor(0.0f, 1.0f, 1.0f);
		glVertex(0, 1, 1);

		glColor(1.0f, 1.0f, 1.0f);
		glVertex(1, 1, 1);
		glColor(0.0f, 1.0f, 1.0f);
		glVertex(0, 1, 1);
		glColor(0.0f, 0.0f, 1.0f);
		glVertex(0, 0, 1);
		glColor(1.0f, 0.0f, 1.0f);
		glVertex(1, 0, 1);

		glColor(1.0f, 1.0f, 1.0f);
		glVertex(1, 1, 1);
		glColor(1.0f, 0.0f, 1.0f);
		glVertex(1, 0, 1);
		glColor(1.0f, 0.0f, 0.0f);
		glVertex(1, 0, 0);
		glColor(1.0f, 1.0f, 0.0f);
		glVertex(1, 1, 0);

	glEnd();
	glPopMatrix();
}


void Object::update(Uint32 time)
{

	if (turnsRight && ! turnsLeft)
		right(time);

	if (turnsLeft && ! turnsRight)
		left(time);

	if (goesForward && ! goesBackwards)
		forward(time);

	if (goesBackwards && ! goesForward)
		back(time);

	goesForward = goesBackwards = turnsRight = turnsLeft = false;

	thePosition = glVertex3D<GLfloat>(
			thePosition.x(),
			World::theWorld()->heightAt(thePosition.x(), thePosition.z()),
			thePosition.z());

}

const double radPerMillisec = 0.0012566371f; // ==>> 360� in 5 seconds

void Object::left(Uint32 time)
{
	float angle = time * radPerMillisec;
	GLfloat matrix[9] = { cos(angle), 0, -sin(angle),
				0, 1, 0,
				sin(angle), 0, cos(angle)
		};
	glMatrix3x3<GLfloat> left10 ( matrix );

	theForwardVector = left10.mult(theForwardVector);

}

void Object::right(Uint32 time)
{
	float angle = -(time * radPerMillisec);
	GLfloat matrix[9] = { cos(angle), 0, -sin(angle),
				0, 1, 0,
				sin(angle), 0, cos(angle)
	};
	glMatrix3x3<GLfloat> right10 ( matrix );

	theForwardVector = right10.mult(theForwardVector);

}

const float millisecondsPerMeter = 500;
void Object::forward(Uint32 time)
{

	thePosition += (theForwardVector * ( (float)time / millisecondsPerMeter) );
}

void Object::back(Uint32 time)
{

	thePosition -= (theForwardVector * ( (float)time / millisecondsPerMeter ));
}

