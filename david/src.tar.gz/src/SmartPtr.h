#ifndef __SmartPtr_H__
#define __SmartPtr_H__

#include <cassert>

template<class TARGET>
class SmartPtr
{
public:
	explicit SmartPtr(TARGET* ptr = 0)
		: theCount(new int), thePtr(ptr) 
	{
		if (thePtr)
			(*theCount) = 1;
		else
			(*theCount) = 0;
	}

	SmartPtr(const SmartPtr<TARGET>& other)
		: theCount(other.theCount), thePtr(other.thePtr) 
	{
		incr();
	}

	~SmartPtr() { 
		decr();
	}

	TARGET* operator->() const {
		assert(thePtr);
		return thePtr;
	}
	
	TARGET& operator*() const { return *thePtr; }

	SmartPtr<TARGET>& operator= (const SmartPtr<TARGET>& rhs)
	{
		decr();
		theCount = rhs.theCount;
		thePtr = rhs.thePtr;
		incr();
		return *this;
	}

	operator bool() { return (thePtr != 0); }

protected:
	void incr() { ++(*theCount); }
	void decr()
	{
		--(*theCount);
		if ((*theCount == 0) && thePtr)
		{
			delete theCount;
			theCount=0;
			delete thePtr;
			thePtr = 0;
		}
	}

private:
	int* theCount;
	TARGET* thePtr;
};


#endif /* ifndef __SmartPtr_H__ */
