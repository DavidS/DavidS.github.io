#ifndef __Player_H__
#define __Player_H__

#include "Object.h"

/**
 * The Player in the World
 */

class Player
	: public Object
{

public:

	Player() { };
	virtual ~Player() { };

private:

};


#endif /* __Player_H__ */
