
#include "OpenGLMath.h"
#include "OpenGL.h"
#include "Camera.h"
#include "World.h"

#include <cmath>
#include <iostream>
using namespace std;
#include <GL/glu.h>

using namespace GL;

Camera::Camera(SmartPtr<Object> followThis)
: theForwardVector(0.0f, 0.0f, -1.0f),
  theUpVector(0.0f, 1.0f, 0.0f),
  theObject(followThis)
{
}

Camera::~Camera() 
{
}

void Camera::updateGL()
{
	// reset projection
	glMatrixMode( GL_PROJECTION );
	glLoadIdentity();
	gluPerspective( 60.0, 640.0/480.0, 1.0, 1024.0 );
	// initialise camera view
	glMatrixMode( GL_MODELVIEW );
	glLoadIdentity();

	float dirX = theObject->forwardVector().x();
	float dirZ = theObject->forwardVector().z();

	float forwardHeight = World::theWorld()->heightAt( theObject->position().x() + dirX , theObject->position().z() + dirZ);
	float backHeight = World::theWorld()->heightAt( theObject->position().x() - (dirX/2.0) , theObject->position().z() - (dirZ/2.0));
	glVertex3D<GLfloat> direction = glVertex3D<GLfloat>(dirX, forwardHeight - backHeight, dirZ);
	direction.normalize();

	glVertex3D<GLfloat> position = theObject->position()
		- 5.0f * direction
		+ glVertex3D<GLfloat>(0.0, 2.0, 0.0);
	gluLookAt( position, theObject->position() + theObject->forwardVector(), theUpVector);
}

void Object::normalizeForwardVector()
{
}
