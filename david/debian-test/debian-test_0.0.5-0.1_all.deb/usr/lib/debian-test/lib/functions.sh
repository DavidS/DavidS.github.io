# -*-shell-*-

# $Id: functions.sh,v 1.6 2000/04/13 08:34:28 phil Exp $
# Copyright (c) 1998 Philip Hands <phil@hands.com>
# Distributed under the terms of the GPL.

####
# Test support functions, to aid in writting tests as shell scripts
#
# include them in your tests, thus:
#
#    . ${DEBIANTEST_LIB}/functions.sh
#    ^^
#    (That's a full-stop, followed by a space)
####

####
# function to run a test, top and tailed with appropriate info lines
runtest() {
description=$1; shift

echo "debian-test TESTING: $description"

  if ( eval $@ )
  then
    result="PASSED"
  else
    result="FAILED"
  fi

echo "debian-test RESULT: $description: $result"
}

####
# put out a message that will get to the user in -s (summary) mode
printmsg() {
  echo "debian-test MESSAGE: $*"
}
